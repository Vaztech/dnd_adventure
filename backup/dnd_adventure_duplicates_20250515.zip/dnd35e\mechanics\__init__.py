
# Use absolute imports consistently
from .combat import CombatSystem as Combat  # Renamed during import
from .magic import Magic